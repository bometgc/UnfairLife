using UnityEngine;

[AddComponentMenu("Objects/Car")]
public class Car : MonoBehaviour
{
    
    [SerializeField] private string name; // name of car
    [SerializeField] private int minSpeed; // minimum speed of car
    [SerializeField] private int maxSpeed; // maximum speed of car
    [SerializeField] private float spawnChance; // chance of spawn car

    public Car(string name, int maxSpeed, int minSpeed, float spawnChance)
    {
        this.name = name;
        this.maxSpeed = maxSpeed;
        this.minSpeed = minSpeed;
        this.spawnChance = spawnChance;
    }
}
