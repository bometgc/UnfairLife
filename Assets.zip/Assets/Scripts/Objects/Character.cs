using UnityEngine;

[AddComponentMenu("Objects/Car")]
public class Character : MonoBehaviour
{
    [SerializeField] private string name; // name of char
    
    public Character(string name)
    {
        this.name = name;
    }
}