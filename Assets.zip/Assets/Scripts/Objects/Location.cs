using UnityEngine;

[AddComponentMenu("Objects/Car")]
public class Location : MonoBehaviour
{
    [SerializeField] private string name; // name of location
    [SerializeField] private int spawnChance; // chance of spawn

    public Location(string name)
    {
        this.name = name;

    }
}