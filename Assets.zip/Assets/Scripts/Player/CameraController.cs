﻿using UnityEngine;
using DG.Tweening;

public class CameraController : MonoBehaviour
{
    public Transform target; // Ссылка на трансформ игрока
    public float followSpeed = 5f; // Скорость следования камеры

    private Vector3 offset; // Смещение между камерой и игроком

    private void Start()
    {
        // Вычисляем начальное смещение между камерой и игроком
        offset = transform.position - target.position;
    }

    private void LateUpdate()
    {
        // Вычисляем целевую позицию камеры
        Vector3 targetPosition = target.position + offset;

        // Используем DoTween для плавного перемещения камеры к целевой позиции
        transform.DOMove(targetPosition, 1f / followSpeed);
    }
}