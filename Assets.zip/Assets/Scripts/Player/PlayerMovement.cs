using UnityEngine;
using DG.Tweening;

public class PlayerMovement : MonoBehaviour
{
    [Header("Grid Preferences")]
    [Tooltip("Size Of Grid (meters)")]
    [SerializeField]
    [Range(1f, 2f)]
    private float gridSize = 1.2f;
    
    [Space(1)]
    
    [Header("Jump Preferences")]
    [Tooltip("Height Of Jump (meters)")]
    [SerializeField]
    [Range(0.3f, 1f)]
    private float jumpHeight = 0.5f;
    
    [SerializeField]
    [Tooltip("Duration Of Jump (seconds)")]
    [Range(0.1f, 0.5f)]
    private float jumpDuration = 0.3f;
    
    [SerializeField]
    [Header("Debug")]
    [Tooltip("Position Of Player When Movement")]
    private Vector3 targetPosition;
    
    [SerializeField]
    [Tooltip("Is It Moving Player")]
    private bool isMoving = false;
    
    [SerializeField]
    [Tooltip("Is It Jumping Player")]
    private bool isJump = false;

    

    void FixedUpdate()
    {

        if (!isMoving)
        {
            
            if (Input.GetKeyDown(KeyCode.W))
            {
                Move(Vector3.forward);
            }
            
            else if (Input.GetKeyDown(KeyCode.S))
            {
                Move(Vector3.back);
            }
            else if (Input.GetKeyDown(KeyCode.A))
            {
                Move(Vector3.left);
            }
            else if (Input.GetKeyDown(KeyCode.D))
            {
                Move(Vector3.right);
            }
        }
    }

    void Move(Vector3 direction)
    {
        targetPosition = transform.position + direction * gridSize;
        float maxHeight = transform.position.y + jumpHeight;
        isMoving = true;

        transform.DOJump(targetPosition, maxHeight, 1, jumpDuration).OnComplete(() =>
        {
            isMoving = false;
        });
        
        Quaternion targetRotation = Quaternion.LookRotation(direction);
        transform.DORotateQuaternion(targetRotation, jumpDuration);

    }
}