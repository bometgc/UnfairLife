using UnityEngine.SceneManagement;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public void Exit()
    {
        Application.Quit();
    }
    public void Menu()
    {
        SceneManager.LoadScene(0);
    }
    public void Play()
    { 
        SceneManager.LoadScene(1);
    }
    public void Shop()
    {
        SceneManager.LoadScene(2);
    }
}    