using System.Collections.Generic;
using UnityEngine;

public class TileGenerator : MonoBehaviour
{
    public GameObject[] tilePrefabs;
    public Transform player;
    public int startTiles = 6;

    private List<GameObject> activeTiles = new List<GameObject>();
    private float spawnPosZ = 0f;
    private float tileLength = 16f;
    private float safeZone = 60f;
    private int lastPrefabIndex = 0;

    private void Start()
    {
        for (int i = 0; i < startTiles; i++)
        {
            SpawnTile();
        }
    }

    private void Update()
    {
        if (player.position.z - safeZone > (spawnPosZ - startTiles * tileLength))
        {
            SpawnTile();
            DeleteTile();
        }
    }

    private void SpawnTile()
    {
        GameObject tile = Instantiate(GetRandomTilePrefab(), transform.forward * spawnPosZ, Quaternion.identity);
        activeTiles.Add(tile);
        spawnPosZ += tileLength;
    }

    private void DeleteTile()
    {
        Destroy(activeTiles[0]);
        activeTiles.RemoveAt(0);
    }

    private GameObject GetRandomTilePrefab()
    {
        if (tilePrefabs.Length == 1)
        {
            return tilePrefabs[0];
        }

        int randomIndex = Random.Range(0, tilePrefabs.Length);
        while (randomIndex == lastPrefabIndex)
        {
            randomIndex = Random.Range(0, tilePrefabs.Length);
        }

        lastPrefabIndex = randomIndex;
        return tilePrefabs[randomIndex];
    }
}